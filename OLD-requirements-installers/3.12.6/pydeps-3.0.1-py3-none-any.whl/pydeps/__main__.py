from .pydeps import pydeps
pydeps()
